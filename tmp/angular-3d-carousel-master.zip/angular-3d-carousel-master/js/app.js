(function() {

'use strict';

angular.module('app', ['angular-3d-carousel']);

})();
